# road traffic > release-640-filtered
https://universe.roboflow.com/object-detection/road-traffic

Provided by Roboflow
License: CC BY 4.0

